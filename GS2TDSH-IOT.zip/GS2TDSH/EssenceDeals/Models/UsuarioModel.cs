﻿using EssenceDeals.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EssenceDeals.Models
{
    [Table("TB_CADASTRO")]
    public class UsuarioModel

    {
        [Column("CodUsuario")]
        [Display(Name = "CodUsuario")]
        [Key]
        public int CodUsuario { get; set; }

        [Column("Nome")]
        [Display(Name = "Nome")]
        public string Nome { get; set; }

        [Column("Login")]
        [Display(Name = "Login")]
        public string Login { get; set; }

        [Column("Email")]
        [Display(Name = "Email")]
        public string email { get; set; }

        [Column("Perfil")]
        [Display(Name = "Perfil")]
        public PerfilEnum Perfil { get; set; }

        [Column("Senha")]
        [Display(Name = "Senha")]
        public string Senha { get; set; }

        [Column("DataCadastro")]
        [Display(Name = "DataCadastro")]
        public DateTime DataCadastro { get; set; }

        [Column("DataAtualizacao")]
        [Display(Name = "DataAtualizcao")]
        public DateTime? DataAtualizacao { get; set; }


        public bool SenhaValida(string senha)
        {
            return Senha == senha;

        }
    }
}
