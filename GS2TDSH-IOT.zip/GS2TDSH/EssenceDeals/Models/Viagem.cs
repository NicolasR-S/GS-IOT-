﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EssenceDeals.Models
{
    [Table("Viagem")]
    public class Viagem
    {
        [Column("CodViagem")]
        [Display(Name="CodigoViagem")]
        [Key]
        public int CodViagem { get; set; }


        [Column("Endereco")]
        [Display(Name="Endereco")]
        public string Endereco { get; set; }


        [Column("QuantPessoas")]
        [Display(Name ="QuantPessoas")]
        public int QuantPessoas { get; set; }

     



    }
}
