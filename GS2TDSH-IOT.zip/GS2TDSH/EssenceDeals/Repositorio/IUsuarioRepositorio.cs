﻿using EssenceDeals.Models;

namespace EssenceDeals.Repositorio
{
    public interface IUsuarioRepositorio
    {

        UsuarioModel BuscarPorLogin(string login);


    }
}
