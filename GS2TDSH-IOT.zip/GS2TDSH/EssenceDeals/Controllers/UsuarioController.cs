﻿using Microsoft.AspNetCore.Mvc;

namespace EssenceDeals.Controllers
{
    public class UsuarioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
