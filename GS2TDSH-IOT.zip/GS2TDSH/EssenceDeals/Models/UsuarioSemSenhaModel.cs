﻿using EssenceDeals.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EssenceDeals.Models
{
    [Table("TB_CADASTRO")]
    public class UsuarioSemSenhaModel

    {
        [Column("CodUsuario")]
        [Display(Name = "CodUsuario")]
        [Key]
        public int CodUsuario { get; set; }

        [Column("Nome")]
        [Display(Name = "Nome")]
        [Required(ErrorMessage = "Digite o nome do usuário")]
        public string Nome { get; set; }


        [Column("Login")]
        [Display(Name = "Login")]
        [Required(ErrorMessage = "Digite o Login do usuário")]
        public string Login { get; set; }

        [Column("Email")]
        [Display(Name = "Email")]
        [Required(ErrorMessage = "Digite o email do usuário")]
        public string email { get; set; }

        [Column("Perfil")]
        [Display(Name = "Perfil")]
        [Required(ErrorMessage = "Informe o perfil do usuário")]
        public PerfilEnum Perfil { get; set; }

   



    }
}
