﻿using EssenceDeals.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EssenceDeals.Repositorio
{
    public class UsuarioRepositorio : IUsuarioRepositorio
    {
        private readonly Contexto _context;

        public UsuarioRepositorio(Contexto contexto)
        {
            this._context = contexto;
        }

        public UsuarioModel BuscarPorLogin(string login)
        {
#pragma warning disable CS8603 // Possível retorno de referência nula.
            return _context.Usuarios.FirstOrDefault(x => x.Login.ToUpper() == login.ToUpper());
#pragma warning restore CS8603 // Possível retorno de referência nula.
        }
    }
}
